# Customer Churn Analysis — Task 2

Analyze customer data to identify patterns behind subscription cancellations.

## Files

```
task2/
├── generate_data.py    <- Step 1: create the dataset
├── churn_analysis.py   <- Step 2: run full analysis
├── requirements.txt
└── README.md
```

After running, these are generated:
- `customer_data.csv`   — synthetic dataset (1240 customers)
- `churn_analysis.png`  — 4 visualisation charts
- `churn_report.txt`    — full analysis log

## Setup & Run

```bash
pip install -r requirements.txt
python generate_data.py
python churn_analysis.py
```

## What it does

| Step | Analysis |
|------|----------|
| 1 | Load & overview — churn rate summary |
| 2 | Segment analysis — by plan, tenure, activity |
| 3 | Behavioral analysis — churned vs retained comparison |
| 4 | Random Forest model — ROC-AUC score + feature importance |
| 5 | Visualizations — 4 charts saved as PNG |
| 6 | Retention recommendations — 6 prioritised actions |
