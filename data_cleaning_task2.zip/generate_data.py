"""
Generate synthetic customer dataset for churn analysis.
Run this first to create customer_data.csv
"""

import pandas as pd
import numpy as np

np.random.seed(42)
n = 1240

plans = np.random.choice(['Basic', 'Pro', 'Enterprise'], n, p=[0.55, 0.32, 0.13])

tenure_months = np.where(plans == 'Enterprise',
    np.random.normal(22, 6, n),
    np.where(plans == 'Pro',
        np.random.normal(11, 4, n),
        np.random.normal(6, 3, n)
    )
).clip(0.5, 48).round(1)

login_freq = np.where(plans == 'Enterprise',
    np.random.normal(5.5, 1.2, n),
    np.where(plans == 'Pro',
        np.random.normal(3.8, 1.5, n),
        np.random.normal(2.1, 1.8, n)
    )
).clip(0, 14).round(1)

features_used = np.where(plans == 'Enterprise',
    np.random.randint(7, 12, n),
    np.where(plans == 'Pro',
        np.random.randint(3, 9, n),
        np.random.randint(0, 5, n)
    )
)

support_tickets = np.where(plans == 'Enterprise',
    np.random.poisson(0.5, n),
    np.where(plans == 'Pro',
        np.random.poisson(1.2, n),
        np.random.poisson(2.5, n)
    )
).clip(0, 10)

payment_failures = np.where(plans == 'Enterprise',
    np.random.poisson(0.1, n),
    np.where(plans == 'Pro',
        np.random.poisson(0.4, n),
        np.random.poisson(0.9, n)
    )
).clip(0, 5)

onboarding_done = np.where(plans == 'Enterprise',
    np.random.choice([0, 1], n, p=[0.05, 0.95]),
    np.where(plans == 'Pro',
        np.random.choice([0, 1], n, p=[0.20, 0.80]),
        np.random.choice([0, 1], n, p=[0.45, 0.55])
    )
)

team_size = np.where(plans == 'Enterprise',
    np.random.randint(5, 30, n),
    np.where(plans == 'Pro',
        np.random.randint(1, 8, n),
        np.random.randint(1, 3, n)
    )
)

session_duration = np.where(plans == 'Enterprise',
    np.random.normal(38, 10, n),
    np.where(plans == 'Pro',
        np.random.normal(24, 9, n),
        np.random.normal(12, 7, n)
    )
).clip(1, 90).round(1)

# Churn probability based on features
churn_score = (
    (login_freq < 2).astype(int) * 0.35 +
    (features_used < 2).astype(int) * 0.25 +
    (support_tickets >= 3).astype(int) * 0.20 +
    (payment_failures >= 1).astype(int) * 0.15 +
    (onboarding_done == 0).astype(int) * 0.20 +
    (team_size == 1).astype(int) * 0.10 +
    (plans == 'Basic').astype(int) * 0.15 +
    (plans == 'Enterprise').astype(int) * -0.30 +
    np.random.normal(0, 0.1, n)
).clip(0, 1)

churned = (churn_score > 0.45).astype(int)

df = pd.DataFrame({
    'customer_id': [f'C{str(i).zfill(4)}' for i in range(1, n+1)],
    'plan': plans,
    'tenure_months': tenure_months,
    'login_freq_weekly': login_freq,
    'features_used': features_used,
    'support_tickets': support_tickets,
    'payment_failures': payment_failures,
    'onboarding_complete': onboarding_done,
    'team_size': team_size,
    'avg_session_min': session_duration,
    'churned': churned
})

df.to_csv('customer_data.csv', index=False)
print(f"Dataset created: {len(df)} customers, {df['churned'].sum()} churned ({df['churned'].mean()*100:.1f}%)")
